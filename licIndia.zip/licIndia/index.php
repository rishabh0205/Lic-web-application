<?php
	$title = 'LIC Policy Management System..!';
	$page = 'index';
	include_once 'header.php';
	include_once 'home.php';
	include_once 'footer.php';
?>